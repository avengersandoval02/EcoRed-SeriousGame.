using UnityEngine;
using UnityEngine.SceneManagement; // ¡Esto es clave para cambiar de escenas!

public class MainMenuManager : MonoBehaviour
{
    [Header("Paneles de Interfaz")]
    // Esta variable guardará tu panel de créditos para poder mostrarlo/ocultarlo
    [SerializeField] private GameObject creditsPanel;

    // --- FUNCIONES PARA LOS BOTONES ---

    // 1. Esta función carga la escena del juego
    public void PlayGame()
    {
        // ¡IMPORTANTE! El texto entre comillas debe ser EXACTAMENTE el nombre de la escena de tu nivel
        SceneManager.LoadScene("GameScene"); 
    }

    // 2. Esta función muestra el panel de créditos
    public void OpenCredits()
    {
        if (creditsPanel != null) 
        {
            creditsPanel.SetActive(true); // Activa el panel
        }
    }

    // 3. Esta función oculta el panel de créditos (para el botón de cerrar o volver)
    public void CloseCredits()
    {
        if (creditsPanel != null) 
        {
            creditsPanel.SetActive(false); // Desactiva el panel
        }
    }

    // 4. Esta función cierra el juego (solo funciona cuando compilas el juego final)
    public void QuitGame()
    {
        Debug.Log("Saliendo del juego..."); // Mensaje en consola para saber que funciona en el editor
        Application.Quit();
    }
}