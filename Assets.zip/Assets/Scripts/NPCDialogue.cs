using UnityEngine;
using TMPro;

[System.Serializable]
public struct DialogueLine
{
    public string speakerName;
    [TextArea(2, 5)] public string text;
}

public class NPCDialogue : MonoBehaviour
{
    [Header("Conversación")]
    [SerializeField] private DialogueLine[] conversation;

    [Header("Solo para el NPC final")]
    [SerializeField] private bool isFinalNPC = false;
    [SerializeField] private string finalNpcName = "Administrador de Red";
    [TextArea(2, 4)]
    [SerializeField] private string incompleteMessage = "Todavía faltan módulos por recolectar. ¡Sigue buscando!";

    [Header("Referencias UI")]
    [SerializeField] private GameObject dialoguePanel;
    [SerializeField] private TMP_Text nameText;
    [SerializeField] private TMP_Text contentText;
    [SerializeField] private GameObject interactionPrompt;

    private bool playerInRange = false;
    private bool dialogueActive = false;
    private bool showingIncomplete = false;
    private int currentLine = 0;

    private void Start()
    {
        if (dialoguePanel != null) dialoguePanel.SetActive(false);
        if (interactionPrompt != null) interactionPrompt.SetActive(false);
    }

    private void Update()
    {
        if (!playerInRange) return;

        if (Input.GetKeyDown(KeyCode.E))
        {
            if (!dialogueActive) StartDialogue();
            else NextLine();
        }
    }

    private void StartDialogue()
    {
        showingIncomplete = false;

        if (isFinalNPC && GameHUDManager.Instance != null && !GameHUDManager.Instance.MissionComplete)
        {
            showingIncomplete = true;
            dialogueActive = true;
            dialoguePanel.SetActive(true);
            if (interactionPrompt != null) interactionPrompt.SetActive(false);
            nameText.text = finalNpcName;
            contentText.text = incompleteMessage + "\nFaltan: " + GameHUDManager.Instance.Remaining + " módulos";
            return;
        }

        if (conversation.Length == 0) return;

        dialogueActive = true;
        currentLine = 0;
        dialoguePanel.SetActive(true);
        if (interactionPrompt != null) interactionPrompt.SetActive(false);
        ShowLine();
    }

    private void NextLine()
    {
        if (showingIncomplete)
        {
            EndDialogue();
            return;
        }

        currentLine++;
        if (currentLine < conversation.Length) ShowLine();
        else EndDialogue();
    }

    private void ShowLine()
    {
        nameText.text = conversation[currentLine].speakerName;
        contentText.text = conversation[currentLine].text;
    }

    private void EndDialogue()
    {
        bool finishedFinalDialogue = dialogueActive && !showingIncomplete;

        dialogueActive = false;
        showingIncomplete = false;
        dialoguePanel.SetActive(false);
        if (playerInRange && interactionPrompt != null) interactionPrompt.SetActive(true);

        if (finishedFinalDialogue && isFinalNPC
            && GameHUDManager.Instance != null && GameHUDManager.Instance.MissionComplete)
        {
            GameHUDManager.Instance.ShowMissionComplete();
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerInRange = true;
            if (!dialogueActive && interactionPrompt != null)
                interactionPrompt.SetActive(true);
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerInRange = false;
            dialogueActive = false;
            showingIncomplete = false;
            dialoguePanel.SetActive(false);
            if (interactionPrompt != null) interactionPrompt.SetActive(false);
        }
    }
}