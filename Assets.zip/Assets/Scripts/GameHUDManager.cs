using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class GameHUDManager : MonoBehaviour
{
    public static GameHUDManager Instance { get; private set; }

    [Header("Textos")]
    [SerializeField] private TMP_Text counterText;
    [SerializeField] private TMP_Text readingsText;
    [SerializeField] private TMP_Text objectiveText;

    [Header("Inventario (5 iconos, opcional)")]
    [SerializeField] private Image[] slotIcons;
    [SerializeField] private Color emptyColor = new Color(0.25f, 0.25f, 0.25f, 0.6f);

    [Header("Misión cumplida")]
    [SerializeField] private GameObject missionCompletePanel;
    [SerializeField] private float panelSeconds = 0f; // 0 = se queda visible

    [Header("Metas")]
    [SerializeField] private int totalRequired = 5;
    [SerializeField] private int totalReadings = 2;

    private int currentCollected = 0;
    private int currentReadings = 0;

    public bool MissionComplete { get { return currentCollected >= totalRequired; } }
    public int Remaining { get { return Mathf.Max(0, totalRequired - currentCollected); } }

    private void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
    }

    private void Start()
    {
        currentCollected = 0;
        currentReadings = 0;
        if (missionCompletePanel != null) missionCompletePanel.SetActive(false);

        foreach (Image icon in slotIcons)
            if (icon != null) icon.color = emptyColor;

        UpdateTexts();
    }

    public void AddCollectible(int amount)
    {
        int previous = currentCollected;
        currentCollected += amount;

        for (int i = previous; i < currentCollected && i < slotIcons.Length; i++)
            if (slotIcons[i] != null) slotIcons[i].color = Color.white;

        UpdateTexts();

        if (MissionComplete && objectiveText != null)
            objectiveText.text = "¡Módulos completos! Habla con el Administrador de Red";
    }

    public void AddReading()
    {
        currentReadings++;
        UpdateTexts();
    }

    public void ShowMissionComplete()
    {
        if (missionCompletePanel == null) return;
        missionCompletePanel.SetActive(true);
        CancelInvoke(nameof(HidePanel));
        if (panelSeconds > 0f) Invoke(nameof(HidePanel), panelSeconds);
    }

    private void UpdateTexts()
    {
        if (counterText != null)
            counterText.text = "Módulos: " + currentCollected + " / " + totalRequired;
        if (readingsText != null)
            readingsText.text = "Datos leídos: " + currentReadings + " / " + totalReadings;
    }

    private void HidePanel()
    {
        missionCompletePanel.SetActive(false);
    }
}