using UnityEngine;
using TMPro;

public class InteractableObject : MonoBehaviour
{
    [Header("UI")]
    [SerializeField] private GameObject promptText;
    [SerializeField] private GameObject infoPanel;
    [SerializeField] private TMP_Text infoTextComponent;

    [Header("Contenido educativo")]
    [TextArea(4, 8)]
    [SerializeField] private string educationalContent;

    private bool playerNearby = false;
    private bool panelOpen = false;
    private bool alreadyCounted = false;

    private void Start()
    {
        if (promptText != null) promptText.SetActive(false);
        if (infoPanel != null) infoPanel.SetActive(false);
    }

    private void Update()
    {
        if (playerNearby && Input.GetKeyDown(KeyCode.E))
        {
            panelOpen = !panelOpen;
            infoPanel.SetActive(panelOpen);
            promptText.SetActive(!panelOpen);

            if (panelOpen)
            {
                infoTextComponent.text = educationalContent;

                if (!alreadyCounted && GameHUDManager.Instance != null)
                {
                    alreadyCounted = true;
                    GameHUDManager.Instance.AddReading();
                }
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerNearby = true;
            if (!panelOpen) promptText.SetActive(true);
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerNearby = false;
            panelOpen = false;
            promptText.SetActive(false);
            infoPanel.SetActive(false);
        }
    }
}