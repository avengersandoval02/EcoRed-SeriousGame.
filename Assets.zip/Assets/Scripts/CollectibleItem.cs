using UnityEngine;

public class CollectibleItem : MonoBehaviour
{
    [SerializeField] private int itemValue = 1;
    private bool isCollected = false;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (isCollected || !other.CompareTag("Player")) return;

        isCollected = true;

        if (GameHUDManager.Instance != null)
            GameHUDManager.Instance.AddCollectible(itemValue);

        Destroy(gameObject);
    }
}