using UnityEngine;

public class FallRespawn : MonoBehaviour
{
    [SerializeField] private float fallLimitY = -10f;
    private Vector3 startPos;
    private Rigidbody2D rb;

    private void Start()
    {
        startPos = transform.position;
        rb = GetComponent<Rigidbody2D>();
    }

    private void Update()
    {
        if (transform.position.y < fallLimitY)
            Respawn();
    }

    public void Respawn()
    {
        transform.position = startPos;
        rb.linearVelocity = Vector2.zero;
    }
}