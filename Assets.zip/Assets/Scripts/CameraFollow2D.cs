using UnityEngine;

public class CameraFollow2D : MonoBehaviour
{
    [Header("Objetivo")]
    [SerializeField] private Transform target;

    [Header("Seguimiento")]
    [SerializeField] private float smoothSpeed = 5f;
    [SerializeField] private float offsetY = 1f;
    [SerializeField] private float deadZoneX = 1.5f;

    [Header("Límites del nivel")]
    [SerializeField] private bool useLimits = true;
    [SerializeField] private float minX = -5f;
    [SerializeField] private float maxX = 25f;

    private void LateUpdate()
    {
        if (target == null) return;

        Vector3 pos = transform.position;
        float deltaX = target.position.x - pos.x;

        if (Mathf.Abs(deltaX) > deadZoneX)
            pos.x = target.position.x - Mathf.Sign(deltaX) * deadZoneX;

        pos.y = target.position.y + offsetY;
        pos.z = -10f;

        if (useLimits)
            pos.x = Mathf.Clamp(pos.x, minX, maxX);

        transform.position = Vector3.Lerp(transform.position, pos, smoothSpeed * Time.deltaTime);
    }
}